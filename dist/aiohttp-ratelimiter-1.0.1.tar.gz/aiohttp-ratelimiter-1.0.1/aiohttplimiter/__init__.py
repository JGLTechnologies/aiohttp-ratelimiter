from aiohttplimiter import RateLimitDecorator
from aiohttplimiter.decorators import default_keyfunc

limit = RateLimitDecorator