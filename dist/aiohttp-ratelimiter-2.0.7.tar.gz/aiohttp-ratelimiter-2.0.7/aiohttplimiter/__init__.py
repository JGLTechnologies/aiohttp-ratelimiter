from .decorators import RateLimitDecorator, default_keyfunc, Limiter

limit = RateLimitDecorator