from .decorators import RateLimitDecorator, default_keyfunc

limit = RateLimitDecorator